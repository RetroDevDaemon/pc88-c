# xdisk3

This is a port of cisc-san's excellent xdisk2, an RS232 PC-88xx disk and ROM read/write tool, for unix systems (using file-type read and write operations). 

Currently only supports writing images, but supports both baudrates.

From the `pc` folder simply type `make`. Run the file to see usage(). 

Built and tested on a Pi400 + PC-8801mkII/FR.

(Branch "old" is simply a mirror of xdisk 2.0.7)
